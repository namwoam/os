gcc ./3_14.c -o 3_14
gcc ./3_15.c -o 3_15
gcc ./3_20.c -o filecopy